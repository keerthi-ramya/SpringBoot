package com.dev.test.SpringBootDevExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDevExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDevExampleApplication.class, args);
	}

}
