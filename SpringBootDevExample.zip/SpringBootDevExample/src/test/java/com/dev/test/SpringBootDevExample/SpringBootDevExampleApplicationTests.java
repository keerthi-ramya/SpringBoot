package com.dev.test.SpringBootDevExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDevExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
